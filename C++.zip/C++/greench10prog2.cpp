#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// Function to get the computer's choice
int getComputerChoice() {
    return rand() % 5 + 1;
}

// Function to determine the winner
string determineWinner(int userChoice, int computerChoice) {
    if (userChoice == computerChoice) {
        return "It's a tie!";
    } else if ((userChoice == 1 && (computerChoice == 3 || computerChoice == 4)) ||
               (userChoice == 2 && (computerChoice == 1 || computerChoice == 5)) ||
               (userChoice == 3 && (computerChoice == 2 || computerChoice == 4)) ||
               (userChoice == 4 && (computerChoice == 2 || computerChoice == 5)) ||
               (userChoice == 5 && (computerChoice == 1 || computerChoice == 3))) {
        return "You win!";
    } else {
        return "Computer wins!";
    }
}

int main() {
    // Seed the random number generator
    srand(time(0));

    while (true) {
        // Display menu and get user's choice
        cout << "Rock, Paper, Scissors, Lizard, Spock Game" << endl;
        cout << "1. Rock\n2. Paper\n3. Scissors\n4. Lizard\n5. Spock\n6. Quit" << endl;
        cout << "Enter your choice (1-6): ";
        int userChoice;
        cin >> userChoice;

        // Check for valid input
        if (userChoice < 1 || userChoice > 6) {
            cout << "Invalid choice. Please choose a number between 1 and 6." << endl;
            continue;
        }

        // Get computer's choice
        int computerChoice = getComputerChoice();

        // Determine the winner using the function
        cout << determineWinner(userChoice, computerChoice) << endl;

        // Ask if the user wants to play again
        cout << "Do you want to play again? (yes/no): ";
        string playAgain;
        cin >> playAgain;

        if (playAgain != "yes") {
            cout << "Thanks for playing!" << endl;
            break;
        }
    }

    return 0;
}
