# print("I love pizza")
# print("It's really good!")
# print("It's really good!")

# variable = a container for a value. Behaves as the value that it comes with

# first_name = "Colin"
# last_name = "Green"
# full_name = first_name +" "+ last_name
# print("Hello " +name)
# print(type(name)) data type of a function
# print("Hello "+full_name)

# age = 21
# age += 1
# print(age)
# print(type(age))


# floating can store a decimanl number
# height = 250.5
# print("Your height is: "+str(height)+"cm")
# print(type(height))

# boolean variable that can only store true or false

# human = True
# print("Are you a human: "+str(human))
# print(type(human))

# strings store a series of characters
# ints store a whole integer 
# floats are floating point numbers a numeric value with a decimanl
# booleans only store true or false

# multiple assignment = allows us to assign mul[tiple variables  at the same time in one line of code

# name = "Colin"
# age = 21
# attractive = False

# name, age, attractive = "Colin", 21, True

# print(name)
# print(age)
# print(attractive)


# Spongebob = 30
# Patrick = 30
# Sandy = 30
# Squidward = 30

# Spongebob = Patrick = Sandy = Squidward = 30

# print(Spongebob)
# print(Patrick)
# print(Sandy)
# print(Squidward)

# name = "Colin "

# print(len(name))
# print(name.find("C"))
# print(name.capitalize())
# print(name.upper())
# print(name.lower())
# print(name.isdigit())
# print(name.isalpha())

